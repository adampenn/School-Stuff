#include <iostream>

using namespace std;

int main()
{
  cout << "What is The Answer to the Ultimate Question of Life, the Universe, and Everything?" << endl;
  int num;
  cin >> num;

  if(num == 42)
  {
    cout << "You are correct" << endl;
  }
  else
  {
    cout << "Nope" << endl;
  }

  return 0;
}

