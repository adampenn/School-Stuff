#include <iostream>
using namespace std;

int main()
{
  char ascii;
  cout << "Enter a character" << endl;
  cin >> ascii;
  cout << (int) ascii << endl;
  
  return 0;
}
