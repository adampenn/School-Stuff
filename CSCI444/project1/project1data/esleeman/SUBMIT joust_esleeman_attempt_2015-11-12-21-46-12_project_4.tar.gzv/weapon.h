#ifndef WEAPON_H
#define WEAPON_H
#include <iostream>
#include <string>

using namespace std;

class Weapon
{
  private:
    string weapon_type;
    int stamina;
    int hit_chance;

  public:
    Weapon(string type, int sr, int hc);
    int get_stamina_required();
    bool did_you_hit();
    void display();
};

#endif


