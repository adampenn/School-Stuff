#include <iostream>
#include <string>
#include "weapon.h"
#include "Random.h"

using namespace std;

  Weapon::Weapon(string type, int sr, int hc)
    :hit_chance(hc), stamina(sr), weapon_type(type)
{
}

bool Weapon::did_you_hit()
{
  Random theGenerator(1,100);
  int rn;
  rn = theGenerator.get();
  if(rn <= hit_chance)
    return true;
  else
    return false;
}

int Weapon::get_stamina_required()
{
  return (stamina);
}

void Weapon::display()
{
  cout << weapon_type << " has a hit chance of " << hit_chance << " and requires " << stamina << " to use." << endl;
}
