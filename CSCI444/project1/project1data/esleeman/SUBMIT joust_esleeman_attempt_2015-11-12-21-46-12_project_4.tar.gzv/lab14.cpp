#include <iostream>
#include <algorithm>
using namespace std;

void sortie(int first, int second, int third)

{
  if (i < first)
  {
    i = first;
  }

  if (i < second)
  {
    i = second;
  }
 
  if (i < third)
  {
    i = third;
  }
}

int main()
{
  cout << "Enter three numbers ";
  int first, second, third;
  cin >> first >> second >> third;
  cout << "Unsorted: " << first << ", " << second << ", " << third << endl;
  sortie(first, second, third);
  cout << "Sorted:   " << first << ", " << second << ", " << third << endl;
  return 0;
}


