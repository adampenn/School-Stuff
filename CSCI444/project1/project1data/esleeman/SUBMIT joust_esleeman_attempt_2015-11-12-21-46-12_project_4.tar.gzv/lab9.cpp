#include <iostream>
using namespace std;

int main()
{
  int first;
  int second;

  cout << "Enter in two integers" << endl;
  cin >> first;
  cin >> second;

  bool sumthemup(int first, int second);

  if (first + second > 10)
  {
    cout << "The sum is greater than 10" << endl;
  }

  else
  {
    cout << "The sum is less than or equal to 10" << endl;
  }

  return 0;
}

