#include <iostream>
#include <string>
#include <vector>

using namespace std;

int main()
{
  vector<string> mylist;
  cout << "Enter your shopping list. Enter * to indicate you are done." << endl;
  string list;
  getline(cin,list);

  while(list != "*")
  {
    mylist.push_back(list);
    getline(cin,list);
  }

  cout << "Here is your list." << endl;
  for(int i=0; i<mylist.size(); i++)
  {
    cout << mylist[i] << endl;
  }
  return 0;
}
