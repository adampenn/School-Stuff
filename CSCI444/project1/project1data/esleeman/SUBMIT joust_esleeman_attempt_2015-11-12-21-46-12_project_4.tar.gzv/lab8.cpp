#include <iostream>
#include <fstream>
using namespace std;

int main()
{
  string file;
  string first;
  int second;
  string third;

  cout << "What is the name of the file?" << endl;
  cin >> file;

  ifstream myfile;
  myfile.open ("test.txt");

  getline(myfile, first);
  myfile >> second;
  myfile.ignore();
  getline(myfile, third);

  cout << "The name is: " << first << endl;
  cout << "The age is: " << second << endl;
  cout << "The snack is: " << third << endl;

  myfile.close();

  return 0;
}
