/*
 * Project 1
 * C++ Programming 
 * Elmo Sleeman
*/

#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
  //Welcome to my Number Guessing Game
  srand(time(NULL));
  int randomNumber;
  randomNumber = rand() %10 + 1;
  int guess;

  cout << "Welcome to the program!" << endl;
  cout << "Guess the computer's number between one and ten." << endl;
  cin >> guess;

  if(guess == randomNumber)
  {
    cout << "You, guessed correctly! You win!" << endl;
  }
  if(guess != randomNumber)
  {
    cout << "I'm sorry, that is not correct. You lose." << endl;
  }

  return 0;
}

