#include <iostream>
#include <string>
#include <cstdlib>

using namespace std;

struct adventurer
{
  string name;
  bool alive_and_well;
};

struct adventurer takeLeftPassage(struct adventurer explorer)
{
  cout << "Going left you reach a large intersection that looks similiar to Mario Kart." << endl;
  cout << "As you attempt to cross the street you see a massive amount of go-karts racing past." << endl;
  cout << "Unable to find another way around, you see a broken down kart, smoking from an apparent crash." << endl;
  cout << "Unsure if you should take it, you think of possibly running to get across." << endl;
  cout << " " << endl;
  cout << "What do you do?" << endl;
  cout << "1) Use the broken down kart to get across the road." << endl;
  cout << "2) Run as fast as you can to get across the road." << endl;

  int health = 100;
  int choice;
  cin >> choice;

  switch(choice) 
  {
    case 1:
      cout << "As you are driving in the kart you are able to successfully get halfway across the road." << endl;
      cout << "Until it suddenly stops causing you to get t-boned by the opposing traffic." << endl;
      cout << "You are sent skidding to the other side of the street. Losing 20 health points from the accident." << endl;
      health = health - 20;
      cout << "As you look at your health bar you see it go from 100 to " << health << "." << endl;
      cout << "Dazed. You continue to explore this strange world." << endl;
      break;

    case 2:
      cout << "As you run across the street, two karts narrowly miss you, but you are able to make it unharmed." << endl;
      cout << "Relieved you continue to explore this strange world." << endl;
      break;
  }

  cout << " " << endl;
  cout << "As you continue walking you suddenly find yourself trapped within a maze." << endl;
  cout << "The walls are so high that you cannot see over them." << endl;
  cout << "White orbs appears in front of you as far as you can see." << endl;
  cout << "Confused you start to hear the original Pac-man music." << endl;
  cout << "And suddenly you see different colored ghosts floating towards you." << endl;
  cout << "When it hits you that you are in Pac-man's place." << endl;
  cout << "As you run past the orbs you realize that points are being added to your highscore." << endl;
  cout << "Running through the maze you reach an intersection with a pink ghost coming from behind and a red ghost in front." << endl;
  cout << "You don't know whether to turn left or right." << endl;
  cout << " " << endl;
  cout << "What do you do?" << endl;
  cout << "1) Turn left." << endl;
  cout << "2) Turn right." << endl;
  cin >> choice;

  if(choice == 1)
  {
    cout << "As you run to the left you see the blue ghost trailing close behind you." << endl;
    cout << "Panicking, you trip over your own two feet causing the ghost to get closer." << endl;
    cout << "But you get back up and are able to run away." << endl;
    cout << "Successfully dodgeing all of the ghosts and collecting the orbs finsihing the game." << endl;
    cout << "The maze disappers and you continue on your way." << endl;
  }

  if(choice == 2)
  {
    cout << "As you run to the right you find yourself caught in a dead end." << endl;
    cout << "Unable to find another way out the ghosts attack you." << endl;
    cout << "Causing you to lose 30 health points." << endl;
    health = health - 30;
    cout << "As you look at your health points you see it at " << health << "." << endl;
    cout << "Causing you to lose the game, but luckily the maze disappers and you continue on your way." << endl;
  }

  cout << " " << endl;
  cout << "You finally reach the end of this world where you see the mysterious red door once again." << endl;
  cout << "Tired and ready to return to the real world, you run as fast as you can to it." << endl;
  cout << "Hoping that everything will go back to the way it was." << endl;
  cout << "As you get about a foot away, it disappers and you suddenly find yourself within the original Donkey Kong game." << endl;
  cout << "Where you hear a voice tell you that you must get to the red door which is 50ft above you on a platform where Donkey Kong is standing." << endl;
  cout << "As you start advancing towards the door, Donkey Kong starts throwing barrels at you that narrowly missess you." << endl;
  cout << "Frustrated you are able to successfully reach the top platform." << endl;
  cout << "Donkey Kong is the only thing standing between you and the real world." << endl;
  cout << "Angered he throws 2 barrels at you." << endl;
  cout << "Quickly you decide of whether to jump over the barrels and run at him head on." << endl;
  cout << "Or try to sneak past under the rolling barrels by going underneath the platform." << endl;
  cout << " " << endl;
  cout << "What do you do?" << endl;
  cout << "1) Run at Donkey Kong head on." << endl;
  cout << "2) Sneak past under the platform." << endl;
  cin >> choice;

  if(choice == 1)
  {
    cout << "As you run at him head on, he picks up another barrel throwing it at you." << endl;
    cout << "You once again dodged it this time by sliding under the flying barrel." << endl;
    cout << "Angered he runs at you." << endl;
    cout << "He reaches out to try and grab you, but you get up in the nick of time getting out of the way." << endl;
    cout << "Running for your life you are getting closer to the mysterious red door." << endl;
    cout << "With Donkey Kong trailing closely behind, you don't know if you can make it." << endl;
    cout << "You successfully get to the door, opening it seeing the real world once again." << endl;
    cout << "As soon as you walk through, Donkey Kong grabs you dragging you back into the 8-bit world." << endl;

    cout << " " << endl;
    cout << "Suddenly you are awaken by your Mom knocking, telling you that you are going to be late for school." << endl;
    cout << "Confused you look around to find yourself in your bedroom." << endl;
    cout << "Looking at your clock you see that it is 7:30am on a Monday morning." << endl;
    cout << "As you look at your t.v. you begin to remember that you were playing a marathon of all of the classic videogames over the weekend." << endl;
    cout << "Forgetting to turn off your t.v. you see the Donkey Kong game paused." << endl;
    cout << "Which may have been the cause of your strange dream." << endl;
    cout << "Still unsure you decide to start getting ready for school." << endl;
    cout << "As you are about to go into the bathroom you grab the remote to turn off the t.v." << endl;
    cout << "As you begin to prepare for another week of school." << endl;

    cout << " " << endl;
    cout << "Thanks for playing my Adventure Explorer game!" << endl;
  }

  if(choice == 2)
  {
    cout << "As you attempt to sneak past under the platform you are successfully able to get past Donkey Kong." << endl;
    cout << "Donkey Kong is confused and is searching for you." << endl;
    cout << "As you continue under the platform, Donkey Kong suddenly looks down directly at you." << endl;
    cout << "Frightened you lose your balance causing you to fall off of the platform." << endl;
    cout << "As you hit the ground you lose 100 health points." << endl;
    health = 0;
    cout << "As you look at your health bar you see that it is at " << health << "." << endl;
    cout << "Saddened. That you won't be able to make it back to the real world." << endl;
    cout << "You look at the red door and see it disappear." << endl;

    cout << " " << endl;
    cout << "You lose the game. Better luck next time." << endl;
  }

  return explorer;
}

struct adventurer takeRightPassage(struct adventurer explorer)
{
  cout << "Going right you come upon a high traffic intersection similiar to the Frogger games." << endl;
  cout << "Being that it's the only way to get further through this game you decide that you have to try and make it across." << endl;
  cout << "Scared to death you unexpectdly make it across the intersection unharmed but find yourself facing a giant roaring river." << endl;
  cout << "Unable to turn back you decide to either jump on the slippery rocks one by one to get to the other side, or try to run across a rickety bridge." << endl;
  cout << " " << endl;
  cout << "What do you do?" << endl;
  cout << "1) Jump on the rocks to get to the other side." << endl;
  cout << "2) Run across the rickety bridge to the other side." << endl;

  int health = 100;
  int choice;
  cin >> choice;

  switch(choice)
  {
    case 1:
      cout << "By jumping across the rocks you are able to successfully make it to the last one." << endl;
      cout << "As you attempt to jump to land you underestimate it, falling into the river." << endl;
      cout << "But you are able to grab ahold of a tree branch pulling yourself to shore." << endl;
      break;

    case 2:
      cout << "As you run across the bridge you realize just how unstable it is." << endl;
      cout << "Halfway across a whole opens up under your feet causing you to fall through directly into the roaring river below." << endl;
      cout << "Washing you downstream." << endl;
      cout << "Where you are able to get out of the river rapids." << endl;
      health = health - 20;
      cout << "But as you look at your health points you see it at " << health << "." << endl;
      break;
  }

  cout << " " << endl;
  cout << "Ready to go back home you continue the journey, where you find a large race track that looks oddly familiar." << endl;
  cout << "As you get closer you see that it is the classic Pole Position racing game." << endl;
  cout << "Seeing all of the cars lined up ready to race, you suddenly hear a voice over the loud speaker telling you to pick a car." << endl;
  cout << "They continue to tell you that you must get within the top 5 or you'll regret it." << endl;
  cout << "With no other opinion, you decide upon a red and white striped race car." << endl;
  cout << "As soon as you sit in the seat you hear the countdown start." << endl;
  cout << "Before you even get your seatbelt on you see all of the race cars speed past you." << endl;
  cout << "In last place you immediately start driving and are able to make it to 8th place." << endl;
  cout << "On the last lap you find yourself in 6th place, but see what looks like a shortcut up ahead." << endl;
  cout << "It looks risky but may help you get within the top 5." << endl;
  cout << " " << endl;
  cout << "What do you do?" << endl;
  cout << "1) Take the shortcut." << endl;
  cout << "2) Try to make it without the shortcut." << endl;
  cin >> choice;

  if(choice == 1)
  {
    cout << "As you take the shortcut your tire smacks the wall, flying off of your wheel." << endl;
    cout << "Directly into the line of traffic causing the top 3 cars to spin out crashing into one another." << endl;
    cout << "Leading into a pile up that you are able to successfully pass up." << endl;
    cout << "Fortunately cauing a blockade for the rest of the competiton." << endl;
    cout << "Successfully getting 1st place, and continuing on your way." << endl;
  }

  if(choice == 2)
  {
    cout << "As you try to make it without the shortcut you are able to successfully get into 5th place." << endl;
    cout << "Until you are suddenly hit from the side from another car causing you to crash into another car." << endl;
    cout << "Causing you to lose 40 health points." << endl;
    health = health - 40;
    cout << "As you look at your health points you see it at " << health << "." << endl;
    cout << "Being that you didn't make it into the top 5 an extra 10 points is taken from your health points." << endl;
    health = health - 10;
    cout << "As you look at your health points you see it at " << health << "." << endl;
    cout << "Unmotivated you continue on your way." << endl;
  }

  cout << " " << endl;
  cout << "You finally reach the end of this world where you see the mysterious red door once again." << endl;
  cout << "Tired and ready to return to the real world, you run as fast as you can to it." << endl;
  cout << "Hoping that everything will go back to the way it was." << endl;
  cout << "As you get about a foot away, it disappers and you suddenly find yourself within the original Donkey Kong game." << endl;
  cout << "Where you hear a voice tell you that you must get to the red door which is 50ft above you on a platform where Donkey Kong is standing." << endl;
  cout << "As you start advancing towards the door, Donkey Kong starts throwing barrels at you that narrowly missess you." << endl;
  cout << "Frustrated you are able to successfully reach the top platform." << endl;
  cout << "Donkey Kong is the only thing standing between you and the real world." << endl;
  cout << "Angered he throws 2 barrels at you." << endl;
  cout << "Quickly you decide of whether to jump over the barrels and run at him head on." << endl;
  cout << "Or try to sneak past under the rolling barrels by going underneath the platform." << endl;
  cout << " " << endl;
  cout << "What do you do?" << endl;
  cout << "1) Run at Donkey Kong head on." << endl;
  cout << "2) Sneak past under the platform." << endl;
  cin >> choice;

  if(choice == 1)
  {
    cout << "As you run at him head on, he picks up another barrel throwing it at you." << endl;
    cout << "You once again dodged it this time by sliding under the flying barrel." << endl;
    cout << "Angered he runs at you." << endl;
    cout << "He reaches out to try and grab you, but you get up in the nick of time getting out of the way." << endl;
    cout << "Running for your life you are getting closer to the mysterious red door." << endl;
    cout << "With Donkey Kong trailing closely behind, you don't know if you can make it." << endl;
    cout << "You successfully get to the door, opening it seeing the real world once again." << endl;
    cout << "As soon as you walk through, Donkey Kong grabs you dragging you back into the 8-bit world." << endl;

    cout << " " << endl;
    cout << "Suddenly you are awaken by your Mom knocking, telling you that you are going to be late for school." << endl;
    cout << "Confused you look around to find yourself in your bedroom." << endl;
    cout << "Looking at your clock you see that it is 7:30am on a Monday morning." << endl;
    cout << "As you look at your t.v. you begin to remember that you were playing a marathon of all of the classic videogames over the weekend." << endl;
    cout << "Forgetting to turn it off your t.v. you see the Donkey Kong game paused." << endl;
    cout << "Which may have been the cause of your strange dream." << endl;
    cout << "Still unsure you decide to start getting ready for class." << endl;
    cout << "As you are about to go into the bathroom you grab the remote to turn off the t.v." << endl;
    cout << "As you begin to prepare for another week of school." << endl;

    cout << " " << endl;
    cout << "Thanks for playing my Adventure Explorer game!" << endl;
  }

  if(choice == 2)
  {
    cout << "As you attempt to sneak past under the platform you are successfully able to get past Donkey Kong." << endl;
    cout << "Donkey Kong is confused and is searching for you." << endl;
    cout << "As you continue under the platform, Donkey Kong suddenly looks down directly at you." << endl;
    cout << "Frightened you lose your balance causing you to fall off of the platform." << endl;
    cout << "As you hit the ground you lose 100 health points." << endl;
    health = 0;
    cout << "As you look at your health bar you see that it is at " << health << "." << endl;
    cout << "Saddened. That you won't be able to make it back to the real world." << endl;
    cout << "You look at the red door and see it disappear." << endl;

    cout << " " << endl;
    cout << "You lose the game. Better luck next time (^.^)." << endl;
  }

  return explorer;
}

int main()
{
  bool win_game = false;
  struct adventurer explorer;
  int health = 100;
  explorer.alive_and_well = true;

  cout << " " << endl;
  cout << "Hello! What is your name?" << endl;
  getline(cin, explorer.name);
  cout << " " << endl;

  cout << "Welcome to the Adventure Explorer Game, " << explorer.name << "." << endl;
  cout << "This is how your story begins." << endl;

  cout << "Walking home from school you decide to take the long way back." << endl;
  cout << "As you aren't looking forward to doing your chores." << endl;
  cout << "Almost home, a mysterious red door appears directly in front of you." << endl;
  cout << "Confused. You decide to walk through the door to find out more." << endl;
  cout << "Leading you into an 8-bit adventure world." << endl;
  cout << "Looking around you see that their is a health bar floating above you." << endl;
  cout << "A mysterious note appears in your hand telling you that you must complete the game in order to return home." << endl;
  cout << "With no other choice you decide to explore the world. Where you come across a fork in the road." << endl;
  cout << "With an arrow pointing left and another pointing right." << endl;
  cout << " " << endl;
  cout << "What do you do?" << endl;

  while(explorer.alive_and_well == true && win_game == false)
  {
    cout << "1) Go left." << endl;
    cout << "2) Go right." << endl;

    int choice;
    cin >> choice;

    system("clear");

    switch(choice)
    {
      case 1:
        explorer = takeLeftPassage(explorer);
        break;

      case 2:
        explorer = takeRightPassage(explorer);
        break;
    }

    return 0;
  }
}

