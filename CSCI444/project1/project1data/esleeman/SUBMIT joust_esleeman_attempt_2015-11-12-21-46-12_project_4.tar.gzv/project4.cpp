#include "Random.h"
#include "weapon.h"
#include "knight.h"
#include <iostream>
#include <string>

using namespace std;

int main()
{
  string k1name;
  int k1stamina;
  string k1weapon_type;
  int k1hit_chance;
  int k1stamina_required;

  cout << "What is the first knights name?" << endl;
  getline(cin, k1name);

  cout << "What is " << k1name << " stamina?" << endl;
  cin >> k1stamina;

  cout << "What is " << k1name << " weapon?" << endl;
  getline(cin, k1weapon_type);

  cout << "What is the weapon's hit chance?" << endl;
  cin >> k1hit_chance;

  cout << "What is the weapon's stamina required to use?" << endl;;
  cin >> k1stamina_required;

  string k2name;
  int k2stamina;
  string k2weapon_type;
  int k2hit_chance;
  int k2stamina_required;

  cout << "What is the second knights name?" << endl;
  getline(cin, k2name);

  cout << "What is " << k2name << " stamina?" << endl;
  cin >> k2stamina;

  cout << "What is " << k2name << " weapon?" << endl;
  getline(cin, k2weapon_type);

  cout << "What is the weapon's hit chance?" << endl;
  cin >> k2hit_chance;

  cout << "What is the weapon's stamina required to use?" << endl;
  cin >> k2stamina_required;

  Knight Knight1(k1name, k1stamina, k1weapon_type, k1hit_chance, k1stamina_required);

  Knight Knight2(k2name, k2stamina, k2weapon_type, k2hit_chance, k2stamina_required);

  do
  {
    bool x = Knight1.wield();
    if(x == true)
    {
      Knight2.unhorse_yourself();
    }
    bool y = Knight2.wield();
    if(y == true)
    {
      Knight1.unhorse_yourself();
    }

    Knight1.display();
    Knight2.display();
  }
  while(Knight1.are_you_exhausted() == false && Knight2.are_you_exhausted() == false && Knight1.are_you_on_horse() == true && Knight2.are_you_on_horse() == true);

  return 0;
}


