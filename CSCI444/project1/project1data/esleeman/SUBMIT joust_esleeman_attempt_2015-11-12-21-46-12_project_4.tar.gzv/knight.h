#ifndef KNIGHT_H
#define KNIGHT_H
#include <iostream>
#include <string>
#include "weapon.h"

using namespace std;

class Knight
{
  private:
    int knight_stamina;
    string knight_name;
    bool on_horse;
    string weapon_in_hand;
     
  public:
    Knight(string n, int stam, string weapon_type, int hit_chance, int stamina_required);
    bool are_you_on_horse();
    void unhorse_yourself();
    bool wield();
    bool attack();
    bool are_you_exhausted();
    void display();
};

#endif
