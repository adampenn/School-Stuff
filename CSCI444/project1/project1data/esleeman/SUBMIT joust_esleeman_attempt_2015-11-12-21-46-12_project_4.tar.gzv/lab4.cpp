#include <iostream>

using namespace std;

int main()
{
  int num;
  cout << "Enter in a number between 1 and 10" << endl;
  cin >> num;
  cout << "You entered in " << num << endl;

  return 0;
}

