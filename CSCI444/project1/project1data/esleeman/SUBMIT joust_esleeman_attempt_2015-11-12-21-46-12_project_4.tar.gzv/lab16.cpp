#include <iostream>
using namespace std;

class Webcounter
{
  public:
    int get()
    {
      return counter;
    }
    void reset()
    {
      counter = 0;
    }
    void set(int value) 
    {
      if (value > 0)
      {
       counter = value;
      }
      else 
      {
        counter = 0;
      }
    }
    void hit()
    {
      ++counter;
    }

  private:
    int counter;
};

int main()
{
  Webcounter wc;
  wc.reset();
  cout << wc.get() << endl;
  wc.hit();
  wc.hit();
  cout << wc.get() << endl;
  wc.reset();
  cout << wc.get() << endl;
  wc.set(3000);
  cout << wc.get() << endl;
  wc.set(-23);
  cout << wc.get() << endl;
  return 0;
}
