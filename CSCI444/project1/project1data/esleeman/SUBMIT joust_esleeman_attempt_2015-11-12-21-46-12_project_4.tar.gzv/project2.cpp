#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

void you_won()
{
  cout << "You Win!" << endl;
}
void you_lost()
{
  cout << "You Lose!" << endl;
}
void you_tied()
{
  cout << "It's a Tie" << endl;
}

int main()
{
  cout << "Let's play Rock, Paper, Scissors" << endl;
  string playAgain = "Y";

  int paper = 0;
  int rock = 0;
  int scissors = 0;

  int won = 0;
  int lost = 0;
  int tied = 0;

  while(playAgain == "Y")
  {
    srand (time(NULL));

    cout << "1 for Rock" << endl;
    cout << "2 for Paper" << endl;
    cout << "3 for Scissors" << endl;

    cout << "Choose a move:" << endl;

    int userChoice;
    cin >> userChoice;
    int cpuChoice = rand() % 3 + 1;

    if(userChoice !=1 && userChoice !=2 && userChoice !=3)
    {
      cout << "Invalid choice" << endl;
    }

    if(userChoice == 1)
    {
      cout << "You picked Rock" << endl;
      rock++;
    }

    if(userChoice == 2)
    {
      cout << "You picked Paper" << endl;
      paper++;
    }

    if(userChoice == 3)
    {
      cout << "You picked Scissors" << endl;
      scissors++;
    }

    if(cpuChoice == 1)
    {
      cout << "Computer picked Rock" << endl;
    }

    if(cpuChoice == 2)
    {
      cout << "Computer picked Paper" << endl;
    }

    if(cpuChoice == 3)
    {
      cout << "Computer picked Scissors" << endl;
    }

    if(userChoice == cpuChoice)
    {
      tied++;
      you_tied();
    }

    if((userChoice == 1 && cpuChoice == 2) || (userChoice == 2 && cpuChoice == 3) || (userChoice == 3 && cpuChoice == 1))
    {
      lost++;
      you_lost();
    }

    if((userChoice == 1 && cpuChoice == 3) || (userChoice == 2 && cpuChoice == 1) || (userChoice == 3 && cpuChoice == 2))
    {
      won++;
      you_won();
    }

    cout << "Would you like to play again (Y for yes, N for no)?" << endl;
    cin >> playAgain;
  }
  cout << "You won " << won << " times." << endl;
  cout << "You lost " << lost << " times." << endl;
  cout << "You tied " << tied << " times." << endl;

  cout << "You used rock " << rock << " times." << endl;
  cout << "You used paper " << paper << " times." << endl;
  cout << "You used scissors " << scissors << " times." << endl;

  return 0;
}

