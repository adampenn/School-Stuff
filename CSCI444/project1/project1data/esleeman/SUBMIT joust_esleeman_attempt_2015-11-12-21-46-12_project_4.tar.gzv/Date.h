#ifndef DATE_H
#define DATE_H

#include <string>

using namespace std;

class Date
{
  public:
    Date(int m, int d, int y);
    void display();

  private:
    int month;
    int day;
    int year;
};

#endif
