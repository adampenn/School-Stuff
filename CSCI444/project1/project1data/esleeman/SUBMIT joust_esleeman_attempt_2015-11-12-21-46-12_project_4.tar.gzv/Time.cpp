#include "Time.h"
#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

Time::Time(int h, int m)
  : hour(h), minute(m)
{
}

void Time::display()
{
  cout << hour << ':' << setw(2) << setfill('0') << minute << endl;
  setfill(' ');
}

