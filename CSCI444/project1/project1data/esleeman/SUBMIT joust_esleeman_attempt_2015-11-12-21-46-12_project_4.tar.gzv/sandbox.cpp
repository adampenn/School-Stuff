#include <iostream>

using namespace std;

int main()
{
  float pi = 3.14;
  int a=3;
  if(a==3)
  {
    float pi=99.99;
    cout << pi;
  }
  cout << pi;
  return 0;
}


