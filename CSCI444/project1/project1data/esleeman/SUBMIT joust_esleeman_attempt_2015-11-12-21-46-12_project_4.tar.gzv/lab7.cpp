#include <iostream>
using namespace std;

int main()
{
  int num;
  char a;
  a='Y';

  cout << "Let's play Rock, Paper, Scissors" << endl;

  while (a == 'Y')
  {
    cout << "Enter 1 for rock, 2 for paper, 3 for scissors" << endl;
    cin >> num;

    switch(num)
    {
      case 1:
        cout << "You chose rock" << endl;
        break;
      case 2:
        cout << "You chose paper" << endl;
        break;
      case 3:
        cout << "You chose scissors" << endl;
        break;

      default:
        cout << num << " is not a valid choice" << endl;
    }
    cout << "Would you like to play again (Y for yes, N for no)?" << endl;
    cin >> a;

  }

  return 0;
}
