#include <iostream>
#include <algorithm>
#include <string>

using namespace std;

int main()
{
  cout << "Please enter a string to shout:" << endl;
  string input;
  getline(cin, input);
 
  transform(input.begin(), input.end(), input.begin(), ::toupper);

  cout << input << endl;

  return 0;
}

