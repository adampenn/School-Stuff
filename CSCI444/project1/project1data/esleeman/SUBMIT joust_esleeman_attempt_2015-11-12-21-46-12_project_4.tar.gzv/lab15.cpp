#include <iostream>

using namespace std;

class Webcounter
{
  public:
    int get()
    {
      return counter;
    }
    void reset()
    {
      counter = 0;
    }

  private:
    int counter;
};

int main()
{
  Webcounter wc;
  wc.reset();
  cout << wc.get() << endl;
  return 0;
}
