#include <iostream>
#include <string>
#include "knight.h"
#include "weapon.h"

using namespace std;

  Knight::Knight(string n, int stam, string weapon_type, int hit_chance, int stamina_required)
:knight_name(n), knight_stamina(stam), weapon_in_hand(weapon_type, hit_chance, stamina_required), on_horse(true)
{
}

void Knight::unhorse_yourself()
{
  on_horse = false;
}

bool Knight::are_you_on_horse()
{
  if(on_horse == true)
     return (true);
  else
     return (false);
}

bool Knight::are_you_exhausted()
{ 
  if(knight_stamina > 0)
    return (false);
  else
    return (true);
}

bool Knight::wield()
{
   int z = weapon_in_hand.stamina_required();
    knight_stamina = knight_stamina - z;

   bool attack = weapon_in_hand.did_you_hit();
    return(attack);
}

void Knight::display()
{
 if(knight_stamina > 0 and on_horse == true)
 {
   cout << knight_name << " is not exhausted " << knight_stamina << " and is still on horse." << endl;
   cout << knight_name << " is using " << weapon_in_hand << endl;
   }
 else if(knight_stamina < 0 and on_horse == true)
 {
   cout << knight_name << " is still on horse but is exhausted. " << endl;
   cout << knight_name << " is using " << weapon_in_hand << endl;
 }
 else if(knight_stamina > 0 and on_horse == false)
 {
   cout << knight_name << " fell off of the horse." << endl;
   cout << knight_name << " is using " << weapon_in_hand << endl;
 }
 else
 {
   cout << knight_name << " fell off of the horse and is exhausted." << endl;
   cout << knight_name << " is using " << weapon_in_hand << endl;
}
}
