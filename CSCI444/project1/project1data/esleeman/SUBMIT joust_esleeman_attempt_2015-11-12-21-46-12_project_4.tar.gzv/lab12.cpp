#include <iostream>
#include <string>
#include <algorithm>

using namespace std;

float average(float*array, int num_elements)
{
  float total=0.0;
  for(int i=0; i<num_elements; i++)
    total=total+array[i];
    total/30;
}

int main()
{
  int num;
  int x;
  float myfloats[30];
  for(int i=0; i<30; i++)
  {
    cin >> num;
    cin >> myfloats[i];
  }

  return 0;
}


