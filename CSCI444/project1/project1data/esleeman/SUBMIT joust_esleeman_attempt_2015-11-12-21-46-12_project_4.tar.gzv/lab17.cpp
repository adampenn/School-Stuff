#include "Date.h"
#include "Time.h"
#include <iostream>

using namespace std;

int main()
{
  Date d(7,4,1776);
  Time t(12,3);
  d.display();
  t.display();
}

