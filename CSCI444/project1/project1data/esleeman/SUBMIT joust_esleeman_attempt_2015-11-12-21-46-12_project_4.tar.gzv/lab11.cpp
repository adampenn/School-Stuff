#include <iostream>
#include <algorithm>
#include <string>

using namespace std;

int main()
{
  cout << "Please enter a string to reverse:" << endl;
  string input;
  getline(cin, input);

  reverse(input.begin(), input.end());
  cout << input << endl;

  return 0;
}

